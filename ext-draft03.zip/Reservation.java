import java.util.ArrayList;

/**
 *  @author TOLENTINO, HEPHZI
 *  @author SANTOS, FRANCINE
 * 
 *  This class represents a reservation made by the user.
 */
public class Reservation {
     /**
      *  These are private attributes under the class Reservation.
      *  
      *  ReserveName is a String that represents the person that reserved a room.
      *  CheckIn is the integer check in date.
      *  CheckOut is the integer check out date.
      *  totalPrice is the total price of the reservation (base price * # of nights).
      *  Status is the status of the reservation ("Reserved" or "Cancelled").
      *  ReserveDays is an array list of Day that stores the span of days in the
      *      reservation.
      *  ReserveRoom is the room chosen by the guest.
      */
     private String ReserveFirstName;
     private String ReserveLastName;

     private String Status;
     private int CheckIn;
     private int CheckOut;

     private float totalPrice;
     private ArrayList<DPM> ratesList;

     private ArrayList<Day> ReserveDays;
     private Room ReserveRoom;



     // CONSTRUCTORS
     /**
      *  Constructs an instance of Reservation with the provided room, name, check in date,
      *      and check out date. Also calls reserveDays() to populate 
      *      the array list ReserveDays based on cIn and cOut.
      * 
      *  @param room The room of reservation.
      *  @param fName The first name of the person who made the reservation.
      *  @param lName The last name of the person who made the reservation.
      *  @param cIn The check in date of the reservation.
      *  @param cOut The check out date of the reservation.
      */
     public Reservation(Room room, String fName, String lName, int cIn, int cOut) {
         this.ReserveFirstName = fName;
         this.ReserveLastName = lName;
         this.CheckIn = cIn;
         this.CheckOut = cOut;
         this.Status = "Reserved";
         this.ratesList = new ArrayList<DPM>();
         this.ReserveRoom = room;
 
         // Populating the ReserveDays
         this.ReserveDays = new ArrayList<Day>();
         reserveDays(cIn, cOut);
     }



     // PUBLIC METHODS
     /**
      *  printReserveDetails() prints all the details of the reservation.
      */
     public void printReserveDetails() {
         int day = CheckOut - CheckIn + 1;
         int night = CheckOut - CheckIn;
 
         System.out.println("     REGISTERED NAME: " + getReserveName());
         System.out.println("     STATUS: " + Status);
         System.out.println("     CHECK IN: June " + CheckIn);
         System.out.println("     CHECK OUT: June " + CheckOut);
         System.out.println("          >> " + day + " DAYS, " + night + " NIGHTS");
         System.out.println("     ROOM: " + ReserveRoom.getRoomName());
         System.out.println("     TYPE: " + ReserveRoom.getRoomType());
         System.out.println("     PRICING: ");
         System.out.println("          BREAKDOWN:   " + ReserveRoom.getRoomPrice() + " x " + night);
         System.out.println("                     -------------");
         System.out.println("          TOTAL PRICE: " + getTotalPrice());
     }


 
     // GETTERS
     /**
      *  Gets the span of days of the reservation.
      * 
      *  @return An array list of Day that represents the reservation days.
      */
     public ArrayList<Day> getReserveDays() {
         return ReserveDays;
     }
 
     /**
      *  Gets the String reserver first name.
      * 
      *  @return A String that represents the first name of the person who made
      *      the reservation.
      */
     public String getReserveFName() {
         return ReserveFirstName;
     }
 
     /**
      *  Gets the String reserver last name.
      * 
      *  @return A String that represents the last name of the person who made
      *      the reservation.
      */
     public String getReserveLName() {
         return ReserveLastName;
     }
 
     /**
      *  Gets the String reserver name.
      * 
      *  @return A String that represents the name of the person who made
      *      the reservation.
      */
     public String getReserveName() {
         return ReserveFirstName + " " + ReserveLastName;
     }
 
     /**
      *  Gets the room assigned to the reservation.
      * 
      *  @return The Room assigned to the reservation.
      */
     public Room getRoom() {
         return ReserveRoom;
     }
 
     /**
      *  Gets the check in date of the reservation.
      * 
      *  @return An integer that represents the check in date obtained
      *      from the array list ReserveDays.
      */
     public int getCheckIn() {
         return ReserveDays.get(0).getDate();
     }
 
     /**
      *  Gets the check out date of the reservation.
      * 
      *  @return An integer that represents the check out date obtained
      *      from the array list ReserveDays.
      */
     public int getCheckOut() {
         return ReserveDays.get(ReserveDays.size() - 1).getDate();
     }
 
     /**
      *  Gets the total price of the reservation.
      * 
      *  @return The float total price of the reservation.
      */
     public float getTotalPrice() {
         return totalPrice;
     }
 
     /**
      *  Gets the status of the reservation.
      * 
      *  @return The String status of the reservation.
      */
     public String getStatus() {
         return Status;
     }


     // SETTERS
     public void setRatesList (ArrayList<DPM> ratesList) {
        this.ratesList = ratesList;
     }
 

     // PRIVATE METHODS
     /**
      *  reserveDays() populates the array list ReserveDays based on cIn and cOut.
      *  Also updates the array list of Day of the room.
      *  
      *  Set to private since only this class will use it.
      */
     private void reserveDays(int cIn, int cOut) {
        ReserveRoom.updateDays(cIn, cOut, "Booked");
        for (int i = cIn; i <= cOut; i++) {
            ReserveDays.add(ReserveRoom.getDay(i)); 
        }
     }

    private int findRate(int day) {
        int i;
        int fDay, lDay;

        for (i = 0; i < ratesList.size(); i++) {
            fDay = this.ratesList.get(i).getFirstDay();
            lDay = this.ratesList.get(i).getLastDay();
            
            if (day == fDay || day == lDay)
                return i;
        }

        return -1;
    }

    // COMPUTATIONS

     /**
      *  computeTotalPrice() computes the total price provided with the base
      *      price of the room.
      * 
      *  @return The total price of the room (base * number of nights).
      */
      public void computeTotalPrice() {
        int i;
        int nights = CheckOut - CheckIn;
        float basePrice = ReserveRoom.getRoomPrice();
        float newPrice;
        
        int day;
        int listIndex;
        DPM newRateDPM;
        float dpmPrice = 0f;

        // Basic computation
        newPrice = basePrice * nights;

        // Date price modifier
       if (ratesList.size() != 0) {
           newPrice = 0f;
           day = 1;

           for (i = 0; i < nights - 1; i++) {
                dpmPrice = basePrice;
                listIndex = findRate(day);
                
                if (listIndex != -1){
                    newRateDPM = ratesList.get(listIndex);

                    if (newRateDPM.getRate() < 1f)
                        dpmPrice = newRateDPM.lessDPM(dpmPrice);
                    else if (newRateDPM.getRate() > 1f)
                        dpmPrice = newRateDPM.moreDPM(dpmPrice);

                    newPrice += dpmPrice;
                }
                else
                    newPrice += basePrice;

                day++;
           }
           newPrice += basePrice;
       }

        this.totalPrice = newPrice;
    }
 }
 