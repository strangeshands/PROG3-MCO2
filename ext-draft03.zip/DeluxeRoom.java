public class DeluxeRoom extends Room {
    public DeluxeRoom(String name, float RoomPrice) {
        super(name, RoomPrice);
        this.RoomType = "DELUXE";
        this.RoomRate = 1.20f;
        setPrice(RoomPrice * RoomRate);
    }

    @Override
    public void setPrice(float newPrice) {
        this.RoomPrice = newPrice * RoomRate;
    }
}