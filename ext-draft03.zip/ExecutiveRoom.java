public class ExecutiveRoom extends Room {
    public ExecutiveRoom(String name, float RoomPrice) {
        super(name, RoomPrice);
        this.RoomType = "EXECUTIVE";
        this.RoomRate = 1.35f;
        this.RoomPrice = RoomPrice * RoomRate;
    }

    @Override
    public void setPrice(float newPrice) {
        this.RoomPrice = newPrice * RoomRate;
    }
}