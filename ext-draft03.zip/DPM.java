public class DPM{
    int firstDay;
    int lastDay;
    float rate;

    public DPM(int firstDay, int lastDay, int rate) {
        this.firstDay = firstDay;
        this.lastDay = lastDay;
        this.rate = (float) rate / 100f;
    }

    public int getFirstDay() {
        return firstDay;
    }

    public int getLastDay() {
        return lastDay;
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }

    public float lessDPM(float basePrice) {
        return basePrice - (basePrice * rate);
    }

    public float moreDPM(float basePrice) {
        return basePrice * rate;
    }
}