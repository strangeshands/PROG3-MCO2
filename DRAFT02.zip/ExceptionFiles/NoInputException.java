package ExceptionFiles;

public class NoInputException extends Exception {
    public NoInputException(String message) {
        super(message);
    }
}
