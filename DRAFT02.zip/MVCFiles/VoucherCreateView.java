package MVCFiles;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;

public class VoucherCreateView extends JDialog {
    private JTextField discountRateField;
    private JTextField discountCodeField;
    private JButton okButton;
    private JButton cancelButton;

    private JTextField numField1;
    private JTextField numField2;

    public VoucherCreateView(JFrame parent, int type) {
        super(parent, "Discount Voucher", true);

        switch (type) {
            case 1 -> type1();
            case 2 -> type2();
            case 3 -> type3();
        }
        
        setLocationRelativeTo(parent);
    }

    private void type1() {
        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(new JLabel("Discount Code:"));
        discountCodeField = new JTextField(10);
        panel.add(discountCodeField);
        panel.add(new JLabel("Discount Rate (%):"));
        discountRateField = new JTextField(10);
        panel.add(discountRateField);

        okButton = new JButton("OK");
        okButton.setActionCommand("OK");
        panel.add(okButton);

        cancelButton = new JButton("Cancel");
        cancelButton.setActionCommand("Cancel");
        panel.add(cancelButton);

        add(panel, BorderLayout.CENTER);
        setSize(250, 125);
    }

    private void type2() {
        JPanel panel = new JPanel(new GridLayout(5, 2));

        panel.add(new JLabel("Discount Code:"));
        discountCodeField = new JTextField(10);
        panel.add(discountCodeField);

        panel.add(new JLabel("Discount Rate (%):"));
        discountRateField = new JTextField(10);
        panel.add(discountRateField);

        panel.add(new JLabel("Date 1 (1-31):"));
        numField1 = new JTextField(10);
        panel.add(numField1);
        
        panel.add(new JLabel("Date 2 (1-31):"));
        numField2 = new JTextField(10);
        panel.add(numField2);

        JPanel buttonPanel = new JPanel();
        okButton = new JButton("OK");
        okButton.setActionCommand("OK");
        buttonPanel.add(okButton);

        cancelButton = new JButton("Cancel");
        cancelButton.setActionCommand("Cancel");
        buttonPanel.add(cancelButton);

        add(panel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        setSize(250, 200);
    }

    private void type3() {
        JPanel panel = new JPanel(new GridLayout(5, 2));

        panel.add(new JLabel("Discount Code:"));
        discountCodeField = new JTextField(10);
        panel.add(discountCodeField);

        panel.add(new JLabel("Discount Rate (%):"));
        discountRateField = new JTextField(10);
        panel.add(discountRateField);

        panel.add(new JLabel("Length of Stay:"));
        numField1 = new JTextField(10);
        panel.add(numField1);
        
        panel.add(new JLabel("Free Day:"));
        numField2 = new JTextField(10);
        panel.add(numField2);

        JPanel buttonPanel = new JPanel();
        okButton = new JButton("OK");
        okButton.setActionCommand("OK");
        buttonPanel.add(okButton);

        cancelButton = new JButton("Cancel");
        cancelButton.setActionCommand("Cancel");
        buttonPanel.add(cancelButton);

        add(panel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        setSize(250, 200);
    }

    public JTextField getDiscountRateField() {
        return discountRateField;
    }

    public JTextField getDiscountCodeField() {
        return discountCodeField;
    }

    public String getNum1Field() {
        return numField1.getText();
    }

    public String getNum2Field() {
        return numField2.getText();
    }

    public JButton getOkButton() {
        return okButton;
    }

    public JButton getCancelButton() {
        return cancelButton;
    }

    public void setActionListener(ActionListener listener) {
        okButton.addActionListener(listener);
        cancelButton.addActionListener(listener);
    }
}
