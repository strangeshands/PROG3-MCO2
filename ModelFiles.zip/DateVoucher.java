package ClassFiles;

public class DateVoucher {
    
}
