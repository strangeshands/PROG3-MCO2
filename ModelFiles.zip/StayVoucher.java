package ClassFiles;

public class StayVoucher {
    
}
