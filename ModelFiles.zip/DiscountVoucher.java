package ClassFiles;

public class DiscountVoucher {
    
}
