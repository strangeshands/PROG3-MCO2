package ClassFiles;

public class DeluxeRoom extends Room {
    public DeluxeRoom(String name, float base) {
        super(name, base);
        setRoomRate(1.35f);
        setPrice(base);
    }

    @Override
    public String getRoomNameType() {
        return getRoomName() + " -- Deluxe";
    }

    @Override
    public String getRoomType() {
        return "Deluxe";
    }
}
