package ClassFiles;

public class Voucher {
    
}
