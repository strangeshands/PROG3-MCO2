package ClassFiles;

public class StayVoucher extends Voucher {
    private int dayLength;
    private int discountedDay;
    private float discount;

    public StayVoucher(String name, float mult, int length, int day) {
        super(name, mult);
        dayLength = length;
        discountedDay = day;
    }

    @Override
    protected float applyDiscount(float base) {
        return base - discount;
    }
    
    @Override
    protected boolean checkApplicable(Reservation reservation) {
        int length = reservation.getCheckOut() - reservation.getCheckIn();
        return length >= dayLength;
    }

    public void setDiscount(Reservation reserv) {
        float dpm = reserv.getReserveDays().get(dayLength).getDPMRate();
        float roomPrice = reserv.getRoom().getRoomPrice();
        discount = roomPrice * dpm * getDiscountMultiplier();
    }

    public float getDiscount() {
        return discount;
    }

    public int getDiscountedDay() {
        return discountedDay;
    }

    public int getDaysLength() {
        return dayLength;
    }

    @Override
    public String getType() {
        return "Stay";
    }

    @Override
    public String getCondition() {
        switch (discountedDay) {
            case 1 -> {
                return  dayLength + " days -- " + discountedDay + "st day";
            }
            case 2 -> {
                return  dayLength + " days -- " + discountedDay + "nd day";
            }
            case 3 -> {
                return  dayLength + " days -- " + discountedDay + "rd day";
            }
            default -> {
                return  dayLength + " days -- " + discountedDay + "th day";
            }
        }
    }
}
