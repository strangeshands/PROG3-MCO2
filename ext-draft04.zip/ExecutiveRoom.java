public class ExecutiveRoom extends Room {
    
    // CONSTRUCTOR
    /**
     * Creates an executive type room.
     * 
     * @param name The room number assigned to it.
     * @param RoomPrice The base price for the executive room.
     * @param dayRates The array containing the rates for the DPM.
     */
    public ExecutiveRoom(String name, float RoomPrice, int dayRates[]) {
        super(name, RoomPrice, dayRates);
        this.RoomType = "EXECUTIVE";
        this.RoomRate = 1.35f;
        this.RoomPrice = RoomPrice * RoomRate;
    }

    /**
     * Sets the executive room's price.
     * Used in price modification.
     */
    @Override
    public void setPrice(float newPrice) {
        this.RoomPrice = newPrice * RoomRate;
    }
}