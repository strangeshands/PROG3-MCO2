import java.util.ArrayList;

/**
 *  @author TOLENTINO, HEPHZI
 *  @author SANTOS, FRANCINE
 * 
 *  This class represents a reservation made by the user.
 */
public class Reservation {
     /**
      *  These are private attributes under the class Reservation.
      *  
      *  ReserveFirstName is a String that represents the first name of the person that reserved a room.
      *  ReserveLastName is a String that represents the last name of the person that reserved a room.
      *  Status is the status of the reservation ("Reserved" or "Cancelled").
      *  CheckIn is the integer check in date.
      *  CheckOut is the integer check out date.
      *  totalPrice is the total price of the reservation (base price * # of nights).
      *  discountCode is the user's inputted voucher code.
      *  ReserveDays is an array list of Day that stores the span of days in the
      *      reservation.
      *  ReserveRoom is the room chosen by the guest.
      */
     private String ReserveFirstName;
     private String ReserveLastName;

     private String Status;
     private int CheckIn;
     private int CheckOut;

     private float totalPrice;
     private String discountCode;

     private ArrayList<Day> ReserveDays;
     private Room ReserveRoom;



     // CONSTRUCTORS
     /**
      *  Constructs an instance of Reservation with the provided room, name, check in date,
      *      and check out date. Also calls reserveDays() to populate 
      *      the array list ReserveDays based on cIn and cOut.
      * 
      *  @param room The room of reservation.
      *  @param fName The first name of the person who made the reservation.
      *  @param lName The last name of the person who made the reservation.
      *  @param cIn The check in date of the reservation.
      *  @param cOut The check out date of the reservation.
      */
     public Reservation(Room room, String fName, String lName, int cIn, int cOut) {
         this.ReserveFirstName = fName;
         this.ReserveLastName = lName;
         this.CheckIn = cIn;
         this.CheckOut = cOut;
         this.Status = "Reserved";
         this.discountCode = " ";
         this.ReserveRoom = room;
 
         // Populating the ReserveDays
         this.ReserveDays = new ArrayList<Day>();
         reserveDays(cIn, cOut);
     }



     // PUBLIC METHODS
     /**
      *  printReserveDetails() prints all the details of the reservation.
      */
     public void printReserveDetails() {
         int day = CheckOut - CheckIn + 1;
         int night = CheckOut - CheckIn;
 
         System.out.println("     REGISTERED NAME: " + getReserveName());
         System.out.println("     STATUS: " + Status);
         System.out.println("     CHECK IN: June " + CheckIn);
         System.out.println("     CHECK OUT: June " + CheckOut);
         System.out.println("          >> " + day + " DAYS, " + night + " NIGHTS");
         System.out.println("     ROOM: " + ReserveRoom.getRoomName());
         System.out.println("     TYPE: " + ReserveRoom.getRoomType());
         System.out.println("     PRICING: ");
         System.out.println("          BREAKDOWN:   " + ReserveRoom.getRoomPrice() + " x " + night);

        if (isCodeValid()) {
            if (discountCode.equals("I_WORK_HERE"))
                System.out.println("          DISCOUNT:   10%");
            else if (discountCode.equals("I_WORK_HERE"))
                System.out.println("          DISCOUNT:   7%");
            else
                System.out.println("          BREAKDOWN:   1 less day");
        }

         System.out.println("                     -------------");
         System.out.println("          TOTAL PRICE: " + getTotalPrice());
     }


 
     // GETTERS
     /**
      *  Gets the span of days of the reservation.
      * 
      *  @return An array list of Day that represents the reservation days.
      */
     public ArrayList<Day> getReserveDays() {
         return ReserveDays;
     }
 
     /**
      *  Gets the String reserver first name.
      * 
      *  @return A String that represents the first name of the person who made
      *      the reservation.
      */
     public String getReserveFName() {
         return ReserveFirstName;
     }
 
     /**
      *  Gets the String reserver last name.
      * 
      *  @return A String that represents the last name of the person who made
      *      the reservation.
      */
     public String getReserveLName() {
         return ReserveLastName;
     }
 
     /**
      *  Gets the String reserver name.
      * 
      *  @return A String that represents the name of the person who made
      *      the reservation.
      */
     public String getReserveName() {
         return ReserveFirstName + " " + ReserveLastName;
     }
 
     /**
      *  Gets the room assigned to the reservation.
      * 
      *  @return The Room assigned to the reservation.
      */
     public Room getRoom() {
         return ReserveRoom;
     }
 
     /**
      *  Gets the check in date of the reservation.
      * 
      *  @return An integer that represents the check in date obtained
      *      from the array list ReserveDays.
      */
     public int getCheckIn() {
         return ReserveDays.get(0).getDate();
     }
 
     /**
      *  Gets the check out date of the reservation.
      * 
      *  @return An integer that represents the check out date obtained
      *      from the array list ReserveDays.
      */
     public int getCheckOut() {
         return ReserveDays.get(ReserveDays.size() - 1).getDate();
     }
 
     /**
      *  Gets the total price of the reservation.
      * 
      *  @return The float total price of the reservation.
      */
     public float getTotalPrice() {
         return totalPrice;
     }
 
     /**
      *  Gets the status of the reservation.
      * 
      *  @return The String status of the reservation.
      */
     public String getStatus() {
         return Status;
     }
 
     /**
      * Sets the reservation's discount code according to user input.
      *
      * @param discountCode is the string input of the user.
      */
     public void setDiscountCode(String discountCode) {
         this.discountCode = discountCode;
     }

     // PRIVATE METHODS
     /**
      *  reserveDays() populates the array list ReserveDays based on cIn and cOut.
      *  Also updates the array list of Day of the room.
      *  
      *  Set to private since only this class will use it.
      */
     private void reserveDays(int cIn, int cOut) {
        ReserveRoom.updateDays(cIn, cOut, "Booked");
        for (int i = cIn; i <= cOut; i++) {
            ReserveDays.add(ReserveRoom.getDay(i)); 
        }
     }

     /**
      * Checks if the user's inputted string is valid.
      * 
      * @return true if valid, false otherwise.
      */
    public boolean isCodeValid() {
        if (discountCode.trim().equals("N/A") ||
            discountCode.trim().isEmpty() == true)
            return false;
        else if (!discountCode.equals("I_WORK_HERE") &&
                !discountCode.equals("STAY4_GET1") &&
                !discountCode.equals("PAYDAY"))
            return false;
        else {
            if (discountCode.equals("STAY4_GET1") && CheckOut - CheckIn < 5)
                return false;
            else if (discountCode.equals("PAYDAY") && 
                (CheckOut == 15 || CheckOut == 30))
                return false;
            
            return true;
        }
     }


    // COMPUTATIONS
     /**
      * Computes the discount according to the discount code.
      *
      * @param discountCode A string representing the user's input.
      * @param cIn The user's check-in date.
      * @param cOut The user's check-out date.
      * @param basePrice The price to place the discount on.
      * @return A float representing the price with an applied discount.
      */
    public float computeDiscount(String discountCode, int cIn, 
                                int cOut, float basePrice) {
        float newPrice = -1f;

        if (discountCode.equals("I_WORK_HERE")) {
            IWorkHere code = new IWorkHere();
            newPrice = code.applyDiscount(basePrice);
        }
        else if (discountCode.equals("STAY4_GET1")) {
            Stay4Get1 code = new Stay4Get1((cOut-cIn));
            newPrice = code.applyDiscount(basePrice);
        }
        else if (discountCode.equals("PAYDAY")) {
            PayDay code = new PayDay();
            newPrice = code.applyDiscount(basePrice);
        }

        return newPrice;
    }

     /**
      *  computeTotalPrice() computes the total price provided 
      *  with the base price of the room.
      */
      public void computeTotalPrice() {
        int i;
        int nights = CheckOut - CheckIn;
        float basePrice = ReserveRoom.getRoomPrice();
        float newPrice;

        // Date price modifier
        newPrice = 0f;

        if (nights == 1)
            newPrice = basePrice;
        else {
            for (i = CheckIn; i < nights; i++) {
                    newPrice += ReserveRoom.getDay(i).getDpm().computeDPM(basePrice);
            }

            newPrice += basePrice;
        }

       // Discount Codes
       if (!discountCode.equals("N/A") &&
            discountCode.trim().isEmpty() == false) {
                newPrice = computeDiscount(discountCode, CheckIn, CheckOut, newPrice);
        }

        this.totalPrice = newPrice;
    }
 }
 