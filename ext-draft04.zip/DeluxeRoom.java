public class DeluxeRoom extends Room {

    // CONSTRUCTOR
    /**
     * Creates a deluxe type room.
     * 
     * @param name The room number assigned to it.
     * @param RoomPrice The base price for the executive room.
     * @param dayRates The array containing the rates for the DPM.
     */
    public DeluxeRoom(String name, float RoomPrice, int dayRates[]) {
        super(name, RoomPrice, dayRates);
        this.RoomType = "DELUXE";
        this.RoomRate = 1.20f;
        setPrice(RoomPrice * RoomRate);
    }

    /**
     * Sets the deluxe room's price.
     * Used in price modification.
     */
    @Override
    public void setPrice(float newPrice) {
        this.RoomPrice = newPrice * RoomRate;
    }
}