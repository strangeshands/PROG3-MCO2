abstract class Discount {
    protected float multiplier;
    protected int daysLength;

    // CONSTRUCTOR
    /**
     * The parent class' constructor used as a template for 
     * its child classes.
     * 
     * @param daysLength is an integer of the number of days 
     *                  a custm=omer has reserved a room.
     */
    public Discount(int daysLength){
        this.daysLength = daysLength;
    }

    // applyDiscount is different for every child class.
    abstract public float applyDiscount(float basePrice);

    /**
     * Mostly for printing purposes.
     * 
     * @return The multiplier or the rate of the discount.
     */
    public float getMultiplier() {
        return multiplier;
    }
}