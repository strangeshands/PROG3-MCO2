public class PayDay extends Discount {
    
    // CONSTRUCTOR
    /**
     * Constructs a discount with PAYDAY features.
     */
    public PayDay() {
        super(0);
        this.multiplier = 0.07f;
    }

    /**
     * Applies the discount to the baseprice.
     * 
     * @param basePrice is the price to be passed when computing for the total.
     * @return is the resulting float after the discount.
     */
    @Override
    public float applyDiscount(float basePrice) {
        return basePrice - (basePrice * multiplier);
    }
}