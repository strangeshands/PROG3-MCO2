public class Stay4Get1 extends Discount {
    
    // CONSTRUCTOR
    /**
     * Constructs a discount with the STAY4_GET1 features.
     * 
     * @param daysLength is an integer of the number of days 
     *                  a customer has reserved a room.
     */
    public Stay4Get1(int daysLength) {
        super(daysLength);
    }

    /**
     * Applies the discount to the baseprice.
     * 
     * @param basePrice is the price to be passed when computing for the total.
     * @return is the resulting float after the discount.
     */
    public float applyDiscount(float basePrice) {
        return basePrice * (daysLength - 1);
    }
}