import java.awt.event.*;
import javax.swing.*;

/**
 * Controller class for the start page.
 * 
 * @author TOLENTINO, HEPHZI (main contributor)
 * @author SANTOS, FRANCINE
 */
public class CONTStart implements ActionListener {
    /**
     * start is the view object for the start page.
     * hrs is the model object for the hotel reservation system.
     */
    VIEWStartPage start;
    MODHRS hrs;

    /**
     * Constructor for the CONTStart class.
     * 
     * @param gui the view object for the start page
     * @param model the model object for the hotel reservation system
     */
    public CONTStart(VIEWStartPage gui, MODHRS model) {
        this.start = gui;
        this.hrs = model;
        
        start.setActionListener(this);
    }

    /**
     * Handles action events from the start page.
     * 
     * @param e the action event
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("CREATE")) {
            // Open a Create Window
            VIEWCreate viewCreate = new VIEWCreate();
            @SuppressWarnings("unused")
            CONTCreate contCreate = new CONTCreate(viewCreate, hrs);
            viewCreate.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        }
        if (e.getActionCommand().equals("VIEW")) {
            VIEWHotelView viewHotel = new VIEWHotelView();
            @SuppressWarnings("unused")
            CONTHotelView contHotel = new CONTHotelView(viewHotel, hrs);
            viewHotel.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        }
        if (e.getActionCommand().equals("BOOK")) {
            // Open a Book Window
            VIEWBook viewBook = new VIEWBook();
            @SuppressWarnings("unused")
            CONTBook contBook = new CONTBook(viewBook, hrs);
            viewBook.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        }
        if (e.getActionCommand().equals("MANAGE")) {
            VIEWManage viewManage = new VIEWManage();
            @SuppressWarnings("unused")
            CONTManage contManage = new CONTManage(viewManage, hrs);
            viewManage.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        }
    }
}
