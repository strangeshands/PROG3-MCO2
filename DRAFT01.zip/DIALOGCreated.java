import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DIALOGCreated extends JDialog {
    private MODHotel hotel;

    public DIALOGCreated(MODHotel hotel, String title) {
        this.hotel = hotel;
        setModal(true);
        setLayout(new BorderLayout());
        setTitle(title);

        JLabel hotelNameLabel = new JLabel("Hotel Name: " + hotel.getHotelName());
        hotelNameLabel.setFont(new Font("Century Gothic", Font.BOLD, 15));
        add(hotelNameLabel, BorderLayout.NORTH);

        JTextArea roomListArea = new JTextArea();
        roomListArea.setFont(new Font("Century Gothic", Font.PLAIN, 12));
        roomListArea.setEditable(false);

        for (int i = 0; i < hotel.getRoomList().size(); i++) {
            roomListArea.append("Room: " + hotel.getRoomList().get(i).getRoomNameType());

            if (i + 1 != hotel.getRoomList().size())
                roomListArea.append("\n");
        }

        add(new JScrollPane(roomListArea), BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Century Gothic", Font.BOLD, 13));
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(closeButton, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setSize(300, 200);
        setMaximumSize(new Dimension(300, 200));
        setMinimumSize(new Dimension(300, 200));
        setVisible(true);
    }
}