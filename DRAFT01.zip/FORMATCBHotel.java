import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;

public class FORMATCBHotel extends JPanel {
    private JComboBox<String> comboBox;

    public FORMATCBHotel() {
        super();
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        comboBox = new JComboBox<>();
        comboBox.setModel(new DefaultComboBoxModel<>(new String[] { "No hotel selected" }));
        comboBox.setPreferredSize(new Dimension(330, 30));

        JPanel ChooseHotelPanel = new JPanel();
        ChooseHotelPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        ChooseHotelPanel.setBackground(new Color(214, 83, 109));
        ChooseHotelPanel.setMaximumSize(new Dimension(350, 35));

        JLabel chooseHotelLabel = new JLabel("Choose Hotel");
        chooseHotelLabel.setFont(new Font("Century Gothic", 1, 15));
        chooseHotelLabel.setForeground(new Color(235, 233, 225));

        JPanel HotelListPanel = new JPanel();
        HotelListPanel.setBackground(new Color(239, 177, 31));
        HotelListPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        HotelListPanel.setMaximumSize(new Dimension(350, 35));

        ChooseHotelPanel.add(chooseHotelLabel);
        HotelListPanel.add(comboBox);

        add(ChooseHotelPanel);
        add(Box.createVerticalStrut(5));
        add(HotelListPanel);
        add(Box.createVerticalStrut(10));
    }

    public void setComboBox(ArrayList<MODHotel> hotelList) {
        String[] stringList = new String[hotelList.size() + 1];

        stringList[0] = "No hotel selected";
        for (int i = 0; i < hotelList.size(); i++) 
            stringList[i + 1] = hotelList.get(i).getHotelName();
    
        ComboBoxModel<String> model = new DefaultComboBoxModel<>(stringList);
        comboBox.setModel(model);
    }

    public String getHotelSelected() {
        String selected = (String)comboBox.getSelectedItem();
        
        return selected;
    }

    public JComboBox<String> getComboBox() {
        return comboBox;
    }
}
