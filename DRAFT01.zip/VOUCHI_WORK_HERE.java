/**
 *  This class is a subclass of MODDiscountVoucher. Applies 10%
 *      discount.
 */
public class VOUCHI_WORK_HERE extends MODDiscountVoucher {
    /**
     *  Constructs a new voucher "I_WORK_HERE."
     */
    public VOUCHI_WORK_HERE() {
        super("I_WORK_HERE", 0.1f);
    }
}