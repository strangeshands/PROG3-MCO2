public class Driver {
    public static void main(String[] args) {
        VIEWStartPage viewStart = new VIEWStartPage();
        MODHRS modHRS = new MODHRS();
        CONTStart contStart = new CONTStart(viewStart, modHRS);
    }
}
