import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class DIALOGSearchByDate extends JDialog {
    private final Font fontLarge = new Font("Century Gothic", Font.BOLD, 15);
    private final Font fontSmallBold = new Font("Century Gothic", Font.BOLD, 12);
    private final Font fontSmallPlain = new Font("Century Gothic", Font.PLAIN, 12);

    public DIALOGSearchByDate(MODHotel hotel, int date) {
        setModal(true);
        setLayout(new BorderLayout());
        setTitle("Search By Date: " + hotel.getHotelName());

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 0));
        FORMATHLInfo hlinfo = new FORMATHLInfo(hotel);
        infoPanel.add(hlinfo);
        infoPanel.setPreferredSize(new Dimension(450, 100));
        add(infoPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        JLabel availLabel = new JLabel("AVAILABILITY FOR JUNE " + date);
        availLabel.setFont(fontLarge);
        centerPanel.add(availLabel);

        ArrayList<MODRoom> freeRooms = hotel.getFreeRooms(date);
        if (!freeRooms.isEmpty()) {
            JLabel availRooms = new JLabel("AVAILABLE ROOMS");
            availRooms.setFont(fontSmallBold);
            centerPanel.add(availRooms);

            JTextArea freeRoomArea = new JTextArea();
            freeRoomArea.setFont(fontSmallPlain);
            freeRoomArea.setEditable(false);
            for (MODRoom room : freeRooms) {
                freeRoomArea.append(">> Room: " + room.getRoomNameType() + "\n");
            }
            centerPanel.add(new JScrollPane(freeRoomArea));
        }

        ArrayList<MODRoom> bookedRooms = hotel.getBookedRooms(date);
        if (!bookedRooms.isEmpty()) {
            JLabel bookRoomLabel = new JLabel("BOOKED ROOMS");
            bookRoomLabel.setFont(fontSmallBold);
            centerPanel.add(bookRoomLabel);

            JTextArea bookedRoomArea = new JTextArea();
            bookedRoomArea.setFont(fontSmallPlain);
            bookedRoomArea.setEditable(false);
            for (MODRoom room : bookedRooms) {
                bookedRoomArea.append(">> Room: " + room.getRoomNameType() + "\n");
            }
            centerPanel.add(new JScrollPane(bookedRoomArea));
        }

        add(centerPanel, BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Century Gothic", Font.BOLD, 13));
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(closeButton, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setSize(400, 400);
        setMaximumSize(new Dimension(400, 400));
        setResizable(false);
        setVisible(true);
    }
}