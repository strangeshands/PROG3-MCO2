import java.awt.*;
import javax.swing.*;

public class FORMATSubmit extends JPanel{
    FORMATButtons submit;
    JLabel status;

    public FORMATSubmit() {
        super();
        setLayout(new BorderLayout());
        //setBackground(Color.decode("#EBE9E2"));
        setMaximumSize(new Dimension(330, 30));

        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        //statusPanel.setBackground(Color.decode("#EBE9E2"));
        statusPanel.setMaximumSize(new Dimension(150, 35));

        status = new JLabel();
        status.setFont(new Font("Century Gothic", Font.PLAIN, 12));
        status.setForeground(Color.decode("#E43D13"));
        statusPanel.add(status);

        submit = new FORMATButtons("SUBMIT");
        
        add(statusPanel, BorderLayout.WEST);
        add(submit, BorderLayout.EAST);
    }

    public JButton getButton() {
        return submit;
    }

    public JLabel getLabel() {
        return status;
    }
}
