import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;

public class FORMATCBRoomSingle extends JComboBox<String> {
    public FORMATCBRoomSingle() {
        super();
        this.setModel(new DefaultComboBoxModel<>(new String[] { "No room selected" }));
        this.setMaximumSize(new Dimension(275, 30));
    }

    public void setComboBox(ArrayList<MODRoom> roomList) {
        String[] stringList = new String[roomList.size() + 1];
        
        stringList[0] = "No room selected";
        for (int i = 0; i < roomList.size(); i++) 
            stringList[i + 1] = roomList.get(i).getRoomNameType();
    
        ComboBoxModel<String> model = new DefaultComboBoxModel<>(stringList);
        this.setModel(model);
    }
    
    public void setComboBox() {
        String[] stringList = new String[1];

        stringList[0] = "No room selected";
    
        ComboBoxModel<String> model = new DefaultComboBoxModel<>(stringList);
        this.setModel(model);
    }

    public String getRoomSelected() {
        return (String)this.getSelectedItem();
    }

    public int getRoomSelectedIndex() {
        return this.getSelectedIndex();
    }
}
