import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.*;

public class DIALOGSearchByRoom extends JDialog {
    private final Font fontSmallPlain = new Font("Century Gothic", Font.PLAIN, 12);
    private final Font fontSmallBold = new Font("Century Gothic", Font.BOLD, 12);

    public DIALOGSearchByRoom(MODHotel hotel, MODRoom room) {
        setModal(true);
        setLayout(new BorderLayout());
        setTitle("Search By Room: " + hotel.getHotelName());

        // Display high level info
        JPanel infoPanel = new JPanel(new BorderLayout());
        infoPanel.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 0));
        FORMATHLInfo hlinfo = new FORMATHLInfo(hotel);
        infoPanel.add(hlinfo, BorderLayout.CENTER);
        infoPanel.setPreferredSize(new Dimension(450, 100));
        add(infoPanel, BorderLayout.NORTH);

        // Display room information
        JPanel centerPanel = new JPanel(new BorderLayout());
        JLabel roomInfoTitle = new JLabel("ROOM INFORMATION -- ");
        roomInfoTitle.setFont(fontSmallBold);
        roomInfoTitle.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 0));
        centerPanel.add(roomInfoTitle, BorderLayout.NORTH);

        JPanel roomInfoPanel = new JPanel();
        roomInfoPanel.setLayout(new GridLayout(3, 1));
        JLabel roomName = new JLabel(">> ROOM: " + room.getRoomName());
        roomName.setFont(fontSmallPlain);
        roomInfoPanel.add(roomName);
        JLabel roomType = new JLabel(">> ROOM TYPE: " + room.getRoomType());
        roomType.setFont(fontSmallPlain);
        roomInfoPanel.add(roomType);
        JLabel roomPrice = new JLabel(">> ROOM PRICE: " + room.getRoomPrice());
        roomPrice.setFont(fontSmallPlain);
        roomInfoPanel.add(roomPrice);

        roomInfoPanel.setBorder(BorderFactory.createEmptyBorder(5, 15, 10, 10));

        centerPanel.add(roomInfoPanel, BorderLayout.CENTER);

        // Display days and status
        ArrayList<MODDay> days = room.getDays();
        String[] columnNames = {"Date", "Status", "Date", "Status", "Date", "Status"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        for (int i = 0; i < days.size(); i++) {
            if (i % 3 == 0) {
                model.addRow(new Object[6]);
            }
            int col = i % 3 * 2;
            model.setValueAt("June " + days.get(i).getDate(), model.getRowCount() - 1, col);
            model.setValueAt(days.get(i).getStatus(), model.getRowCount() - 1, col + 1);
        }

        JTable daysTable = new JTable(model);
        daysTable.setFont(fontSmallPlain);
        daysTable.setRowHeight(20);
        daysTable.setEnabled(false);

        JTableHeader tableHeader = daysTable.getTableHeader();
        tableHeader.setFont(fontSmallBold);

        JScrollPane scrollPane = new JScrollPane(daysTable);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        // Create a new panel to hold the room info and days table
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.add(roomInfoPanel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        centerPanel.add(contentPanel, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);

        // Setting up the close button
        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Century Gothic", Font.BOLD, 13));
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(closeButton, BorderLayout.SOUTH);

        // Other properties of the dialog box
        setLocationRelativeTo(null);
        setSize(450, 400);
        setMaximumSize(new Dimension(450, 400));
        setResizable(false);
        setVisible(true);
    }
}