public class VoucherException extends Exception {
    public VoucherException() {
        super("Invalid Code.");
    }
}
