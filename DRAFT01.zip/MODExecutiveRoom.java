public class MODExecutiveRoom extends MODRoom{
    public MODExecutiveRoom(String name, float base) {
        super(name, base);
        setRoomRate(1.35f);

        setPrice(base);
    }

    @Override
    public String getRoomNameType() {
        return getRoomName() + " -- Executive";
    }

    @Override
    protected String getRoomType() {
        return "Executive";
    }
}
