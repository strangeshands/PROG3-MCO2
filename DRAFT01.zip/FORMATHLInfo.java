import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.*;

public class FORMATHLInfo extends JPanel {
    private final Font font = new Font("Century Gothic", Font.BOLD, 13);

    public FORMATHLInfo(MODHotel hotel) {
        super();
        setLayout(new BorderLayout());

        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel title = new JLabel("WELCOME TO -- " + hotel.getHotelName() + "!");
        title.setFont(font);
        titlePanel.add(title);

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setPreferredSize(new Dimension(250, 200));

        JLabel hotelName = new JLabel(">> HOTEL NAME: " + hotel.getHotelName());
        hotelName.setFont(font);
        JLabel roomNum = new JLabel(">> NUMBER OF ROOMS: " + hotel.getRoomList().size());
        roomNum.setFont(font);
        JLabel estEarn = new JLabel(">> ESTIMATED EARNING: " + hotel.getEstimatedEarning());
        estEarn.setFont(font);

        infoPanel.add(hotelName);
        infoPanel.add(roomNum);
        infoPanel.add(estEarn);


        add(titlePanel, BorderLayout.NORTH);
        add(infoPanel, BorderLayout.CENTER);
    }
}
