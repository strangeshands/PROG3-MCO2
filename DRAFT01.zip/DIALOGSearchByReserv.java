import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DIALOGSearchByReserv extends JDialog {
    private final Font fontLarge = new Font("Century Gothic", Font.BOLD, 15);
    private final Font fontSmallBold = new Font("Century Gothic", Font.BOLD, 12);
    private final Font fontSmallPlain = new Font("Century Gothic", Font.PLAIN, 12);

    public DIALOGSearchByReserv(MODHotel hotel, MODReservation reserv) {
        setModal(true);
        setLayout(new BorderLayout());
        setTitle("Reservation: " + hotel.getHotelName());

        JPanel northPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        JLabel welcome = new JLabel("Welcome, " + reserv.getReserveFName() + "!");
        welcome.setFont(fontLarge);
        northPanel.add(welcome);

        add(northPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        JLabel regName = new JLabel("REGISTERED NAME: " + reserv.getReserveName());
        regName.setFont(fontSmallPlain);
        centerPanel.add(regName);

        JLabel status = new JLabel("STATUS: " + reserv.getStatus());
        status.setFont(fontSmallPlain);
        centerPanel.add(status);

        JLabel room = new JLabel("ROOM: " + reserv.getRoom().getRoomNameType());
        room.setFont(fontSmallPlain);
        centerPanel.add(room);

        JLabel checkIn = new JLabel("CHECK IN: June " + reserv.getCheckIn());
        checkIn.setFont(fontSmallPlain);
        centerPanel.add(checkIn);

        JLabel checkOut = new JLabel("CHECK OUT: June " + reserv.getCheckOut());
        checkOut.setFont(fontSmallPlain);
        centerPanel.add(checkOut);
        centerPanel.add(Box.createVerticalStrut(10));

        JLabel breakdown = new JLabel("PRICE BREAKDOWN:");
        breakdown.setFont(fontSmallBold);
        centerPanel.add(breakdown);

        JTextArea brkdownDetails = new JTextArea();
        brkdownDetails.setEditable(false);
        brkdownDetails.setFont(fontSmallPlain);

        String breakdownDetails =   "ROOM PRICE: " + reserv.getRoom().getRoomPrice() + " x " + 
                                    (reserv.getCheckOut() - reserv.getCheckIn()) + " nights\n";
        breakdownDetails += "TOTAL PRICE: " + reserv.getOriginalPrice();
        breakdownDetails += "\n\t\t\t----------------------\n";

        if (reserv.getVoucher() != null) {
            breakdownDetails += "\nVOUCHER CODE: " + reserv.getVoucher().getDiscountCode();
            breakdownDetails += "\nVOUCHER DISCOUNT: -" + 
                                reserv.getVoucher().getDiscount(reserv.getOriginalPrice()) + 
                                "\n";
            breakdownDetails += "FINAL PRICE: " + reserv.getDiscountedPrice();
        } else {
            breakdownDetails += "\nFINAL PRICE: " + reserv.getDiscountedPrice();
        }

        brkdownDetails.setText(breakdownDetails);
        brkdownDetails.setLineWrap(true);
        brkdownDetails.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(brkdownDetails);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        centerPanel.add(scrollPane);

        add(centerPanel, BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Century Gothic", Font.BOLD, 13));
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(closeButton, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setSize(300, 400);
        setMaximumSize(new Dimension(300, 400));
        setResizable(false);
        setVisible(true);
    }
}
