public class MODLengthDeptVocuher extends MODVoucher {
    private int daysLength;
    private float discount;
    private int dayOfDiscount;

    public MODLengthDeptVocuher(String name, float mult, int length, int day) {
        super(name, mult);
        daysLength = length;
        dayOfDiscount = day;
    }

    @Override
    protected float applyDiscount(float base) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'applyDiscount'");
    }

    @Override
    protected boolean checkApplicable(MODReservation reservation) {
        int reservLength = reservation.getCheckIn() - reservation.getCheckOut();
        return reservLength == daysLength;
    }

    public void setDiscount(float discout) {
        this.discount = discout;
    }

    public float getDayOfDiscount() {
        return dayOfDiscount;
    }
}
