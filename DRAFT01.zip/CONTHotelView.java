import java.awt.event.*;
import java.util.ArrayList;

public class CONTHotelView implements ActionListener, ItemListener {
    private VIEWHotelView view;
    private MODHRS hrs;

    public CONTHotelView(VIEWHotelView gui, MODHRS model) {
        this.view = gui;
        this.hrs = model;
        
        view.setActionListener(this);
        view.setCBHotel(hrs.getHotelList());
        view.setItemListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("DateSUBMIT")) {
            searchByDate();
            view.clearInput();
        }
        else if (e.getActionCommand().equals("RoomSUBMIT")) {
            searchByRoom();
            view.clearInput();
        }
        else if (e.getActionCommand().equals("ReservSUBMIT")) {
            searchByReserve();
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) {
            String search = (String) view.getHotelCB().getComboBox().getSelectedItem();
            MODHotel selectedHotel = hrs.findHotel(search);

            if (selectedHotel == null)
                view.setCBRoom(null);
            else {
                ArrayList<MODRoom> roomList = selectedHotel.getRoomList();
                view.setCBRoom(roomList);
            }
        }
    }

    private void searchByDate() {
        try {
            String hotel = view.getHotelSelected();
            checkSelect(hotel);
            int date = Integer.parseInt(view.getDateInput());
            checkSingleDate(date);

            if (hrs.searchByDate(hotel, date))
                view.clearInput();
            else
                view.setDateSubmitStatus("Please refresh window.");
        } catch (NoSelectionException e) {
            view.setDateSubmitStatus("Please select hotel.");
        } catch (DateException | NumberFormatException e) {
            view.setDateSubmitStatus("Please check your date input.");
        }
    }

    private void searchByRoom() {
        try {
            String hotel = view.getHotelSelected();
            checkSelect(hotel);
            String room = view.getRoomSelected(1);
            checkSelect(room);

            if (hrs.searchByRoom(hotel, room))
                view.setRoomSubmiStatus("Found!");
            else
                view.setRoomSubmiStatus("Please refresh window.");
        } catch (NoSelectionException e) {
            view.setRoomSubmiStatus("Please select hotel and room.");
        }
    }

    private void searchByReserve() {
        String[] inputs = new String[6];
        int cIn, cOut;

        try {
            inputs[0] = view.getHotelSelected();
            checkSelect(inputs[0]);
            inputs[1] = view.getRoomSelected(2);
            checkSelect(inputs[1]);

            inputs[2] = view.getFNameInput();
            checkInput(inputs[2]);
            inputs[3] = view.getLNameInput();
            checkInput(inputs[3]);

            inputs[4] = view.getCInInput();
            cIn = Integer.parseInt(inputs[4]);
            inputs[5] = view.getCOutInput();
            cOut = Integer.parseInt(inputs[5]);
            checkTwoDates(cIn, cOut);

            if (hrs.searchByReserve(inputs, cIn, cOut))
                view.setReservSubmitStatus("Found!");
            else
                view.setReservSubmitStatus("Reservation not found.");
        } catch (NoSelectionException e) {
            view.setReservSubmitStatus("Please select hotel and room.");
        } catch (NoInputException f) {
            view.setReservSubmitStatus("Please fill in all blanks.");
        } catch (NumberFormatException | DateException e) {
            view.setReservSubmitStatus("Please check your dates.");
        }
    }

    // ----- EXCEPTIONS ----- //

    private void checkSelect(String input) throws NoSelectionException {
        if (input.equals("No hotel selected") || input.equals("No room selected"))
            throw new NoSelectionException("No hotel or room selected.");
    }

    private void checkInput(String input) throws NoInputException {
        if (input.equals(""))
            throw new NoInputException("No input.");
    }

    private void checkTwoDates(int cIn, int cOut) throws DateException {
        if ((cIn < 1 || cOut > 31) || cIn >= cOut)
            throw new DateException("Invalid Dates.");
    }

    private void checkSingleDate(int cIn) throws DateException {
        if (cIn < 1 || cIn > 31)
            throw new DateException("Invalid Dates.");
    }
}
