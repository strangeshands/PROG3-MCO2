import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;

public class FORMATCBRoom extends JPanel {
    JComboBox<String> comboBox;

    public FORMATCBRoom() {
        super();
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        comboBox = new JComboBox<>();
        comboBox.setModel(new DefaultComboBoxModel<>(new String[] { "No room selected" }));
        comboBox.setMaximumSize(new Dimension(200, 30));

        JPanel ChooseRoomPanel = new JPanel();
        ChooseRoomPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        ChooseRoomPanel.setBackground(new Color(214, 83, 109));
        ChooseRoomPanel.setMaximumSize(new Dimension(320, 35));

        JLabel chooseRoomLabel = new JLabel("Choose Room");
        chooseRoomLabel.setFont(new Font("Century Gothic", 1, 15));
        chooseRoomLabel.setForeground(new Color(235, 233, 225));

        JPanel RoomListLabel = new JPanel();
        RoomListLabel.setBackground(new Color(239, 177, 31));
        RoomListLabel.setLayout(new FlowLayout(FlowLayout.CENTER));
        RoomListLabel.setMaximumSize(new Dimension(320, 35));

        ChooseRoomPanel.add(chooseRoomLabel);
        RoomListLabel.add(comboBox);

        add(ChooseRoomPanel);
        add(Box.createVerticalStrut(5));
        add(RoomListLabel);
        add(Box.createVerticalStrut(10));
    }

    public void setComboBox(ArrayList<MODRoom> roomList) {
        String[] stringList = new String[roomList.size() + 1];
        
        stringList[0] = "No room selected";
        for (int i = 0; i < roomList.size(); i++) 
            stringList[i + 1] = roomList.get(i).getRoomNameType();
    
        ComboBoxModel<String> model = new DefaultComboBoxModel<>(stringList);
        comboBox.setModel(model);
    }
    
    public void setComboBox() {
        String[] stringList = new String[1];

        stringList[0] = "No room selected";
    
        ComboBoxModel<String> model = new DefaultComboBoxModel<>(stringList);
        comboBox.setModel(model);
    }

    public JComboBox<String> getComboBox() {
        return comboBox;
    }

    public String getRoomSelected() {
        return (String)comboBox.getSelectedItem();
    }
}
