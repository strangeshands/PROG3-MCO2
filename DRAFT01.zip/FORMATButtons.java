import java.awt.*;
import javax.swing.*;

/**
 *  This is a child class of JButton which has its own format according
 *      to the author's liking.
 * 
 *  @author HEPHZI TOLENTINO (main contributor)
 *  @author FRANCINE SANTOS
 */
public class FORMATButtons extends JButton {
    /**
     *  This constructs a big button; this is used in main menu.
     * 
     *  @param btnLabel The String label of a button.
     *  @param icon The icon used for the button.
     */
    public FORMATButtons(String btnLabel, ImageIcon icon) {
        super(btnLabel, icon);

        setFont(new Font("Century Gothic", Font.BOLD, 15));
        setBackground(Color.decode("#D6536D"));
        setForeground(Color.decode("#EBE9E1"));

        setOpaque(true);
        setBorderPainted(false);

        setMargin(new Insets(30, 10, 30, 10));
        setIconTextGap(10);
        setPreferredSize(new Dimension(150, 40));

        setEnabled(true);
        setVisible(true);
    }

    /**
     *  This constructs a small button; this is used mainly for "SUBMIT"
     *      buttons.
     * 
     *  @param btnLabel The String label of a button.
     */
    public FORMATButtons(String btnLabel) {
        super(btnLabel);

        setFont(new Font("Century Gothic", Font.BOLD, 10));
        setBackground(Color.decode("#D6536D"));
        setForeground(Color.decode("#EBE9E1"));

        setOpaque(true);
        setBorderPainted(false);
        setIconTextGap(10);

        setPreferredSize(new Dimension(78, 28));
        setEnabled(true);
    }

    /**
     *  This constructs a small button and allows changing of
     *      colors.
     * 
     *  @param btnLabel The String label of a button.
     *  @param color1 THe background color of a button.
     *  @param color2 The foreground color of a button.
     */
    public FORMATButtons(String btnLabel, String color1, String color2) {
        super(btnLabel);

        setFont(new Font("Century Gothic", Font.BOLD, 10));
        setBackground(Color.decode(color1));
        setForeground(Color.decode(color2));

        setOpaque(true);
        setBorderPainted(false);
        setIconTextGap(10);

        setPreferredSize(new Dimension(78, 28));
    }
}