import java.awt.*;
import javax.swing.*;

public class FORMATLabel extends JLabel {
    public FORMATLabel(String label) {
        super(label);
        setForeground(Color.decode("#E43D12"));
        setFont(new Font("Century Gothic", Font.BOLD, 35));
        setBorder(BorderFactory.createEmptyBorder(25, 45, 0, 0));
    }
}
