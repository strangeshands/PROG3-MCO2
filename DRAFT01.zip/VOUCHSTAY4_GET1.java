public class VOUCHSTAY4_GET1 extends MODLengthDeptVocuher {
    public VOUCHSTAY4_GET1() {
        super("STAY4_GET1", 1.0f, 5, 1);
    }

    public void addDay(MODReservation reserv) {
        int cOut = reserv.getCheckOut();
        reserv.getReserveDays().add(new MODDay(cOut + 1));
    }

    @Override
    protected float applyDiscount(float base) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'applyDiscount'");
    }
    
    @Override
    protected boolean checkApplicable(MODReservation reservation) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'checkApplicable'");
    }
}