public class VOUCHPAYDAY extends MODDateVoucher {
    public VOUCHPAYDAY() {
        super("PAYDAY", 0.07f, 15, 30);
    }
}