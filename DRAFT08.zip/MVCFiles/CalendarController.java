package MVCFiles;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class CalendarController implements ActionListener{
    private CalendarView view;
    private CalendarModel booking;

    private int startDay;
    private int endDay;

    public CalendarController(CalendarView gui, CalendarModel model) {
        this.view = gui;
        this.booking = model;

        startDay = 0;
        endDay = 0;
        
        view.setActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            JButton button = (JButton) e.getSource();
            int selectedDay = Integer.parseInt(button.getText());

            if (startDay == 0) {
                startDay = selectedDay;
                button.setBackground(Color.GREEN);
            }
            else {
                if (endDay != startDay) {
                    endDay = selectedDay;
                    button.setBackground(Color.GREEN);

                    // Disable buttons after the selected end date
                    for (int i = endDay + 1; i <= 31; i++) {
                        JButton dateButton = view.getButton(i - 1);
                        dateButton.setEnabled(false);
                    }
                }
            }

            // Disable buttons before the selected start date
            for (int i = 1; i < startDay; i++) {
                JButton dateButton = view.getButton(i - 1);
                dateButton.setEnabled(false);
            }
        } catch (NumberFormatException d) {
            JButton button = (JButton) e.getSource();
            if (button.getActionCommand().equals("clearDates")) {
                for (int i = 1; i <= 31; i++) {
                    JButton dateButton = view.getButton(i - 1);
                    if (!view.getDisabledDates().contains(dateButton)) { 
                        dateButton.setEnabled(true);
                    }
            
                    startDay = 0;
                    endDay = 0;
                }
            }
            else if (button.getActionCommand().equals(("submitDates"))){
                setDates(startDay, endDay);
                System.out.println(startDay);
                System.out.println(endDay);
                view.dispose();
            }
        }
    }

    private void setDates(int date1, int date2) {
        booking.setDate1st(date1);
        booking.setDate2nd(date2);
    } 

    public int getStartDay() {
        return startDay;
    }

    public int getEndDay() {
        return endDay;
    }
}
