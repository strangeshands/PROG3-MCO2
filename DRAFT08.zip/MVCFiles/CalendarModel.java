package MVCFiles;

public class CalendarModel {
    private int date1st;
    private int date2nd;

    public CalendarModel() {
        date1st = 0;
        date2nd = 0;
    }

    public int getStartDay() {
        return date1st;
    }

    public int getEndDay() {
        return date2nd;
    }

    public void setDate1st(int date) {
        date1st = date;
    }

    public void setDate2nd(int date) {
        date2nd = date;
    }
}
