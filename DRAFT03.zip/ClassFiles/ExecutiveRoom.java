package ClassFiles;

public class ExecutiveRoom extends Room {
    public ExecutiveRoom(String name, float base) {
        super(name, base);
        setRoomRate(1.35f);
        setPrice(base);
    }

    @Override
    public String getRoomNameType() {
        return getRoomName() + " -- Executive";
    }

    @Override
    public String getRoomType() {
        return "Executive";
    }
}
