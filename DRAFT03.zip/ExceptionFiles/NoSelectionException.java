package ExceptionFiles;

public class NoSelectionException extends Exception{
    public NoSelectionException(String message) {
        super(message);
    }
}