package MVCFiles;

import ClassFiles.*;
import DialogFiles.HotelInfo;
import ExceptionFiles.*;
import java.awt.event.*;
import javax.swing.JOptionPane;

/**
 *  CONTManage is thr controller for the VIEWManage window.
 *  
 *  @author TOLENTINO, HEPHZI (main contributor)
 *  @author SANTOS, FRANCINE
 */
public class ManageController implements ActionListener, ItemListener {
    /**
     *  view is the GUI/view for this controller.
     *  hrs is the model for this controller.
     */
    private ManageView view;
    private HRSModel hrs;

    /**
     *  Constructs a controller for the VIEWManage window.
     * 
     *  @param gui The gui to be used.
     *  @param model The model to be used.
     */
    public ManageController(ManageView gui, HRSModel model) {
        this.view = gui;
        this.hrs = model;

        view.setActionListener(this);
        view.setCBHotel(hrs.getHotelList());
        view.setItemListener(this);
    }

    /**
     *  Sets the action for the specific button.
     *  
     *  @param e The action event that happens.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        // Hotel Tab
        if (e.getActionCommand().equals("NameSUBMIT")) {
            changeHotelName();  
        }
        if (e.getActionCommand().equals("DELETE")) {
            deleteHotel();
        }

        // Room Tab
        if (e.getActionCommand().equals("AddSUBMIT")) {
            addRooms();
        }
        if (e.getActionCommand().equals("RemoveSUBMIT")) {
            removeRooms();
        }

        // Price Tab
        if (e.getActionCommand().equals("PriceSUBMIT")) {
            changeRoomPrice();
        }

        // Reservations Tab
        if (e.getActionCommand().equals("RRSUBMIT")) {
            removeReservation();
        }

        // DPM Tab
        if (e.getActionCommand().equals("DPMSUBMIT")) {
            manageDPM();
        }
        if (e.getActionCommand().equals("ViewDPM")) {
            viewDPM();
        }

        // Voucher Tab
        if (e.getActionCommand().equals("VoucherSUBMIT")) {
            createVoucher();
        }
        if (e.getActionCommand().equals("ViewVOUCHER")){
            ViewVoucher();
        }
    }

    /**
     *  Sets the room information according to the hotel selected in the
     *      hotel combo box.
     * 
     *  @param e The event that happened.
     */
    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) {
            String search = (String)view.getHotelCB().getComboBox().getSelectedItem();
            Hotel selectedHotel = hrs.findHotel(search);

            if (selectedHotel == null) {
                view.setCBRooms(null);
                view.setRoomStatus("No hotel selected.");
                view.setPriceTable(0, 0, 0);
            }
            else {
                String message = "CURRENT ROOM COUNT: " + selectedHotel.getRoomList().size();
                view.setRoomStatus(message);

                // Setting up Comboboxes for Rooms
                view.setCBRooms(selectedHotel.getRoomList());

                // Setting up the price label
                float price1 = selectedHotel.getRoomPrice(1);
                float price2 = selectedHotel.getRoomPrice(2);
                float price3 = selectedHotel.getRoomPrice(3);
                view.setPriceTable(price1, price2, price3);
            }
        }
    }

    /**
     *  [DONE] Allows changing of hotel name.
     */
    private void changeHotelName() {
        try {
            String newName = view.getNameInput();
            checkInput(newName);
            String hotel = view.getHotelSelected();
            checkSelect(hotel);

            if (hrs.changeHotelName(hotel, newName)) {
                view.setSubmitStatus("Name successfully changed!", 0);

                String message =    "Hotel name changed from " +
                                    hotel + " to " + newName;
                JOptionPane.showMessageDialog(null, message, "Change Name", 
                                            JOptionPane.INFORMATION_MESSAGE);

                view.clearInputTF();
                view.setSubmitStatus("", 0);
                refreshWindow();
            }
            else
                view.setSubmitStatus("New name already exists.", 0);
        } catch (NoSelectionException e) {
            view.setSubmitStatus("Please select hotel.", 0);
        } catch (NoInputException e) {
            view.setSubmitStatus("Please input needed field.", 0);
        }
    }

    /**
     *  [DONE] Allows deletion of a hotel.
     */
    private void deleteHotel() {
        try {
            String hotel = view.getHotelSelected();
            checkSelect(hotel);

            String message =    "Are you sure you want to delete?\n" +
                                "This hotel has currently " +
                                hrs.getHotelReservNum(hotel) +
                                " reservation/s.\n";
            int option = JOptionPane.showConfirmDialog(null, message, 
                            "Confirm Action", JOptionPane.YES_NO_OPTION);

            if (option == JOptionPane.YES_OPTION) {
                hrs.deleteHotel(hotel);
                view.setDeleteStatus("Successfully deleted.");
                refreshWindow();
            }
            else
                view.setDeleteStatus("Hotel was not deleted.");
        } catch (NoSelectionException e) {
            view.setDeleteStatus("Please select hotel.");
        }
    }

    /**
     *  [DONE] Adds room according to the input.
     */
    private void addRooms() {
        try {
            String hotel = view.getHotelSelected();
            checkSelect(hotel);

            String[] input = view.getAddRoomInput();
            int[] numInputs = new int[3];
            for (int i = 0; i < 3; i++)
                numInputs[i] = tryNumInput(input[i]);

            if (hrs.addRoom(hotel, numInputs[0], numInputs[1], numInputs[2])) {
                view.setSubmitStatus("Rooms successfully added.", 1);

                Hotel selectedHotel = hrs.findHotel(hotel);
                String message = "CURRENT ROOM COUNT: " + selectedHotel.getRoomList().size();
                view.setRoomStatus(message);

                @SuppressWarnings("unused")
                HotelInfo prompt = new HotelInfo(selectedHotel, "New Rooms Added!", 1);
                refreshWindow();
            }
            else
                view.setSubmitStatus("Maximum of 50 rooms only.", 1);
        } catch (NoSelectionException e) {
            view.setSubmitStatus("Please select hotel.", 1);
        }
    }

    /**
     *  [DONE] Removes the selected rooms.
     */
    private void removeRooms() {
        try {
            String hotel = view.getHotelSelected();
            checkSelect(hotel);

            int room1 = view.getRoomSelectedIndex(1);
            int room2 = view.getRoomSelectedIndex(2);
            checkRoomInputs(room1, room2);

            if (room2 == 0)
                room2 = room1;
            
            if (hrs.removeRooms(hotel, room1 - 1, room2 - 1)) {
                view.setSubmitStatus("Rooms successfully removed.", 2);

                // Show the changes made
                refreshWindow();
                String message = "CURRENT ROOM COUNT: " + (hrs.findHotel(hotel)).getRoomList().size();
                view.setRoomStatus(message);

                // Pop up window of the changes made.
                @SuppressWarnings("unused")
                HotelInfo prompt = new HotelInfo(hrs.findHotel(hotel), "Room/s Removed!", 1);
            }
            else
                view.setSubmitStatus("Unable to remove room/s.", 2);

        } catch (NoSelectionException e) {
            view.setSubmitStatus("Please select hotel.", 2);
        } catch (NumberException e) {
            view.setSubmitStatus("Please check room inputs", 2);
        }
    }

    /**
     *  [DONE] Changes the price of the rooms.
     */
    private void changeRoomPrice() {
        try {
            String hotel = view.getHotelSelected();
            checkSelect(hotel);
            Hotel selectedHotel = hrs.findHotel(hotel);

            float newPrice = Float.parseFloat(view.getPriceInput());
            checkPriceInputs(newPrice);

            if (hrs.changeRoomPrice(hotel, newPrice)) {
                view.setSubmitStatus("Price successfully changed.", 3);

                // Setting up the price label
                float price1 = selectedHotel.getRoomPrice(1);
                float price2 = selectedHotel.getRoomPrice(2);
                float price3 = selectedHotel.getRoomPrice(3);
                view.setPriceTable(price1, price2, price3);
                view.clearInputTF();
            }
            else 
                view.setSubmitStatus("Reservation/s found.", 3);
        } catch (NoSelectionException e) {
            view.setSubmitStatus("Please select hotel.", 3);
        } catch (NumberException | NumberFormatException e) {
            view.setSubmitStatus("Minimum base price is 100.", 3);
        } 
    }

    /**
     *  [DONE] Removes the reservation based on the user inputs.
     */
    private void removeReservation() {
        try {
            String hotel = view.getHotelSelected();
            checkSelect(hotel);

            String room = view.getRoomSelected();
            checkSelect(room);

            String fName = view.getFNameInput();
            checkInput(fName);
            String lName = view.getLNameInput();
            checkInput(lName);
            
            int cIn = Integer.parseInt(view.getCInInput());
            int cOut = Integer.parseInt(view.getCOutInput());
            checkTwoDates(cIn, cOut);

            if (hrs.findReservation(hotel, fName, lName, room, cIn, cOut)) 
            {
                // Prompt to confirm
                String message =    "Reservation found.\n" +
                                    "Name: " + fName + " " + lName + "\n" +
                                    "Room: " + room;
                int option = JOptionPane.showConfirmDialog(null, message, 
                            "Confirm Action", JOptionPane.YES_NO_OPTION);

                if (option == JOptionPane.YES_OPTION) {
                    hrs.removeReservation(hotel, fName, lName, room, cIn, cOut);
                    view.setSubmitStatus("Reservation successfully removed.", 4);
                }
                else
                view.setSubmitStatus("Removal cancelled.", 4);
            }
            else
                view.setSubmitStatus("Reservation not found.", 4);
        } catch (NoSelectionException e) {
            view.setSubmitStatus("Please select hotel and room.", 4);
        } catch (NumberException e) {
            view.setSubmitStatus("Invalid dates.", 4);
        } catch (NoInputException e) {
            view.setSubmitStatus("Please fill in all required blanks.", 4);
        } catch (NumberFormatException e) {
            view.setSubmitStatus("Invalid dates.", 4);
        }
    }

    private void manageDPM() {
        try {
            String hotel = view.getHotelSelected();
            checkSelect(hotel);

            int date = Integer.parseInt(view.getDateInput());
            float rate = Float.parseFloat(view.getDPMRateInput());
            checkRateDate(rate, date);

            if (hrs.updateDPM(hotel, date, rate)) {
                view.setDPMSubmitStatus("Successfully updated.");

                Hotel currHotel = hrs.findHotel(hotel);
                @SuppressWarnings("unused")
                HotelInfo dpmView = new HotelInfo(currHotel, "DPM", 2);
            }
            else
                view.setDPMSubmitStatus("Please refresh window.");

        } catch (NumberFormatException | NumberException e) {
            view.setDPMSubmitStatus("Please input valid date and rate.");
        } catch (NoSelectionException e) {
            view.setDPMSubmitStatus("Please select hotel.");
        }
    }

    private void viewDPM() {
        try {
            String hotel = view.getHotelSelected();
            checkSelect(hotel);
            Hotel currHotel = hrs.findHotel(hotel);

            @SuppressWarnings("unused")
            HotelInfo dpmView = new HotelInfo(currHotel, "DPM", 2);
            view.setDPMViewStatus("Click here to view DPM info.");
        } catch (NoSelectionException e) {
            view.setDPMViewStatus("Please select hotel.");
        }
    }

    private void createVoucher() {
        try {
            String hotel = view.getHotelSelected();
            checkSelect(hotel);
            Hotel currHotel = hrs.findHotel(hotel);
            int typeSelect = view.getVoucherType();
            checkType(typeSelect);

            switch (typeSelect) {
                case 1 -> {
                    VoucherCreateView type1 = new VoucherCreateView(view, typeSelect);
                    @SuppressWarnings("unused")
                    VoucherCreateController cont1 = new VoucherCreateController(currHotel, 
                                                        type1, typeSelect);
                }
                case 2 -> {
                    VoucherCreateView type2 = new VoucherCreateView(view, typeSelect);
                    @SuppressWarnings("unused")
                    VoucherCreateController cont1 = new VoucherCreateController(currHotel, 
                                                        type2, typeSelect);
                }
                case 3 -> {
                    VoucherCreateView type3 = new VoucherCreateView(view, typeSelect);
                    @SuppressWarnings("unused")
                    VoucherCreateController cont1 = new VoucherCreateController(currHotel, 
                                                        type3, typeSelect);
                }
            }
        } catch (NoSelectionException e) {
            view.setVoucherSubmitStatus("Please select hotel.");
        } catch (NumberException e) {
            view.setVoucherSubmitStatus("Please select voucher type.");
        }
    }

    private void ViewVoucher() {
        try {
            String hotel = view.getHotelSelected();
            checkSelect(hotel);
            Hotel currHotel = hrs.findHotel(hotel);

            @SuppressWarnings("unused")
            HotelInfo vouView = new HotelInfo(currHotel, "Voucher List", 3);
            view.setVoucherViewStatus("Click here to view Vouchers.");
        } catch (NoSelectionException e) {
            view.setVoucherViewStatus("Please select hotel.");
        }
    }

    

    // ----- PRIVATE METHODS ----- // 

    /**
     *  Refreshes the comboboxes everytime there are changes made.
     */
    private void refreshWindow() {
        view.setCBHotel(hrs.getHotelList());
        view.repaint();
        view.revalidate();

        // Update the comboboxes and labels dependent on the hotel
        view.setCBHotel(hrs.getHotelList());
        view.setCBRooms(null);
        view.setRoomStatus("No hotel selected.");
        view.setPriceTable(0, 0, 0);
    }


    // ----- EXCEPTIONS ----- // 

    /**
     *  Checks the selection of the combo boxes.
     * 
     *  @param input The text acquired from the selected item.
     *  @throws NoSelectionException When the selection is in the default.
     */
    private void checkSelect(String input) throws NoSelectionException {
        if (input.equals("No hotel selected") || input.equals("No room selected"))
            throw new NoSelectionException("No hotel or room selected.");
    }

    /**
     *  Checks if the input is not empty.
     * 
     *  @param input The input from a text field.
     *  @throws NoInputException When the input is empty.
     */
    private void checkInput(String input) throws NoInputException {
        if (input.equals(""))
            throw new NoInputException("No input.");
    }

    /**
     *  Checks if there are selected room inputs. lb can't be 0 and ub can't
     *      be less than lb.
     * 
     *  @param lb The lower bound index.
     *  @param ub The upper bound index.
     *  @throws NumberException When the conditions is not satisfied.
     */
    private void checkRoomInputs(int lb, int ub) throws NumberException {
        if (lb == 0 || (lb > ub && ub != 0))
            throw new NumberException("Invalid selections");
    }

    /**
     *  Checks if the price input is < 100.
     * 
     *  @param price The price input.
     *  @throws NumberException When the price is less than 100.
     */
    private void checkPriceInputs(double price) throws NumberException {
        if (price < 100)
            throw new NumberException("Invalid price");
    }

    /**
     *  Checks the two dates (cIn and cOut) if it satisfies the conditions
     *      cIn >= 1
     *      cOut <= 31
     *      cIn < cOut
     * 
     *  @param cIn The check in date.
     *  @param cOut The check out date.
     *  @throws NumberException When the conditions are not satisfied.
     */
    private void checkTwoDates(int cIn, int cOut) throws NumberException {
        if ((cIn < 1 || cOut > 31) || cIn >= cOut)
            throw new NumberException("Invalid Dates.");
    }

    /**
     *  Tries number inputs and returns the value. 0 if the input is 
     *      not a number.
     * 
     *  @param source The String input that MUST be a number.
     *  @return The parsed integer of the String, 0 if not a number.
     */
    private int tryNumInput(String source) {
        int dest;

        try {
            dest = Integer.parseInt(source);

            if (dest < 0)
                dest = 0;
        } catch (NumberFormatException e) {
            dest = 0;
        }

        return dest;
    }

    /**
     * Checks if the provided type is valid.
     * 
     * @param type the type to be checked
     * @throws NumberException if the type is invalid
     */
    private void checkType(int type) throws NumberException {
        if (type == 0)
            throw new NumberException("Invalid Selection.");
    }

    /**
     * Checks if the provided rate and date are valid.
     * 
     * @param rate the rate to be checked
     * @param date the date to be checked
     * @throws NumberException if the rate or date is invalid
     */
    private void checkRateDate(float rate, int date) throws NumberException {
        if (rate < 1 || date < 1 || date > 31)
            throw new NumberException("Invalid Rate.");
    }
}
