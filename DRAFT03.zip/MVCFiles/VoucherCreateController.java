package MVCFiles;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import ClassFiles.Hotel;
import ExceptionFiles.NumberException;

public class VoucherCreateController implements ActionListener {
    private Hotel hotel;
    private VoucherCreateView view;
    private int type;

    public VoucherCreateController(Hotel model, VoucherCreateView view, int type) {
        this.hotel = model;
        this.view = view;
        this.type = type;

        view.setActionListener(this);
        view.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("OK"))
            createVoucher(type);
        else
            view.setVisible(false);
    }

    public void createVoucher(int type) {
        try {
            String code = view.getDiscountCodeField().getText();
            float rate = Float.parseFloat(view.getDiscountRateField().getText());
            checkRate(rate);
            rate /= 100;

            switch (type) {
                case 1 -> {
                    if (hotel.createVoucherType1(code, rate))
                        JOptionPane.showMessageDialog(view, "Voucher " + code + " added!");
                }
                case 2 -> {
                    int date1 = tryNumInput(view.getNum1Field());
                    int date2 = tryNumInput(view.getNum2Field());
                    checkDate(date1, date2);

                    if (hotel.createVoucherType2(code, rate, date1, date2))
                        JOptionPane.showMessageDialog(view, "Voucher " + code + " added!");
                }
                case 3 -> {
                    int length = Integer.parseInt(view.getNum1Field());
                    checkRate((float)length);
                    int day = Integer.parseInt(view.getNum2Field());
                    checkRate((float)day);

                    if (hotel.createVoucherType3(code, rate, length, day))
                        JOptionPane.showMessageDialog(view, "Voucher " + code + " added!");
                }
            }
        } catch (NumberFormatException | NumberException ex) {
            JOptionPane.showMessageDialog(view, 
            "Invalid input.");
        }
    }
    
    private void checkRate(float rate) throws NumberException {
        if (rate < 0)
            throw new NumberException("Invalid rate.");
    }

    /**
     *  This uses NumberFormatException and returns the number input.
     * 
     *  @param source The input source, mainly from a text field.
     * 
     *  @return The number input in integer format.
     *          0 if the input can't be parsed.
     */
    private int tryNumInput(String source) {
        int dest;

        try {
            dest = Integer.parseInt(source);
        } catch (NumberFormatException e) {
            dest = 0;
        }

        return dest;
    }

    private void checkDate(int date1, int date2) throws NumberException {
        if (date1 < 1 || date1 > 31 || date2 > 31 || date2 < 0)
            throw new NumberException("Invalid date.");
    }
}

