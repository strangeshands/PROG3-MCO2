package FormatFiles;

import java.awt.*;
import javax.swing.*;

public class Submit extends JPanel{
    Buttons submit;
    JLabel status;

    public Submit() {
        super();
        setLayout(new BorderLayout());
        setMaximumSize(new Dimension(330, 30));

        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        statusPanel.setMaximumSize(new Dimension(150, 35));

        status = new JLabel();
        status.setFont(new Font("Century Gothic", Font.PLAIN, 12));
        status.setForeground(Color.decode("#E43D13"));
        statusPanel.add(status);

        submit = new Buttons("SUBMIT");
        
        add(statusPanel, BorderLayout.WEST);
        add(submit, BorderLayout.EAST);
    }

    public JButton getButton() {
        return submit;
    }

    public JLabel getLabel() {
        return status;
    }
}
